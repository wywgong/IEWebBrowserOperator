﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReplaceExample
{
    public class MockMethodReplacer
    {
        
        public static double ConvertToUnixTimestamp(DateTime date)
        {
            return 1;
        }

        public int GetTheNum(int num)
        {
            return num + 10;
        }

        public static void ReplaceWriteLine(bool value)
        {
            if (value)
            {
                Console.WriteLine("ahhh I am true");
            }
            else
            {
                Console.WriteLine("ahhh I am false");
            }
            
        }

        public string GetData(string data)
        {
            return data + "Mocked aHaHa";
        }
    }
}
