using System;
using System.Diagnostics;
using CLRInjection;
using System.Runtime.CompilerServices;
using System.Reflection;

namespace ConsoleApplication2
{
    public class GenericMethodSample
    {
        //[MethodImpl(MethodImplOptions.NoInlining)]
        public static void Test(string[] args)
        {
            MethodInfo sameInfo = typeof(GenericMethodSample).GetMethod("Same");
            MethodInfo inInfo = typeof(GenericMethodSample).GetMethod("Increment");
            
            MethodUtil.ReplaceMethod(inInfo, sameInfo);
            Console.WriteLine(Proxy2(2));


            CalInt c1 = new CalInt();

            MethodInfo i1 = typeof(CalInt).GetMethod("Same");
            MethodInfo i2 = typeof(CalInt).GetMethod("Default");
            MethodInfo m1 = typeof(CalInt).GetMethod("M1");
            MethodInfo m2 = typeof(CalInt).GetMethod("M2");

            MethodUtil.ReplaceMethod(i1, i2);
            MethodUtil.ReplaceMethod(m1, m2);

            Console.WriteLine(Proxy(2));

            Console.WriteLine(Proxy3(7));

            //Got error below code
            /*MethodInfo s1 = typeof(CalString).GetMethod("Same");
            MethodInfo s2 = typeof(CalString).GetMethod("Default");
            MethodInfo sm1 = typeof(CalString).GetMethod("M1");
            MethodInfo sm2 = typeof(CalString).GetMethod("M2");

            MethodUtil.ReplaceMethod(s1, s2);
            MethodUtil.ReplaceMethod(sm1, sm2);
            Console.WriteLine(Proxy4Default("abc"));*/



        }

        public static int Proxy2(int i)
        {
            GenericMethodSample p = new GenericMethodSample();
            return p.Same(i);
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        public static int Proxy(int i)
        {
            CalInt c = new CalInt();
            return c.Default(i);
        }
        private static string Proxy4Default(string i)
        {
            CalString c = new CalString();
            return c.Default(i);
        }
        private static int Proxy3(int i)
        {
            CalInt c = new CalInt();
            return c.M2(i);
        }
                [MethodImpl(MethodImplOptions.NoInlining)]

        public  int Same(int i)
        {
            return i;
        }
                [MethodImpl(MethodImplOptions.NoInlining)]

        public virtual int Increment(int i)
        {
            return i + 1;
        }

        public T Decrease<T>(T t)
        {
            return t;
        }
    }

    abstract class Calculator<T> : IComparable
    {
        public T Same(T t)
        {
            return t;
        }
        public T Default(T t)
        {
            return default(T);
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        public int M1(int i)
        {
            return 1;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        public int M2(int i)
        {
            return 2;
        }

        public int CompareTo(object obj)
        {
            return 0;
        }
    }
    class CalInt : Calculator<int>
    {}

    class CalString : Calculator<string>
    {
        
    }
}
