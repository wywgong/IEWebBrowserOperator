﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ReplaceExample
{
    public interface IMock
    {
        int GetTheNum(int num);


    }
    public class Mock : IMock
    {
        public int GetTheNum(int num)
        {
            return num;
        }

        public int GetTheNumWithoutInterface(int num)
        {
            return num;
        }

        public int GetTheNumWithInterface(int num)
        {
            return GetTheNum(num);
        }
    }
}
