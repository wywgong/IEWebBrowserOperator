﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReplaceExample
{
    public class InstanceClassB
    {
        public void A()
        {
            Console.WriteLine("InstanceClassB.A");
        }
        public void B()
        {
            Console.WriteLine("InstanceClassB.B");
        }
    }
}
