﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using BeInjectedLib;

namespace CLRInjectionTest
{
    public class MethodInterceptor
    {
        public string OwnProperty { get; set; }

        public static string ReplaceStaticGetStringWithOrigin(string org)
        {

            return "I'm mute guy, can't tell you anything";
        }

        public string ReplaceInstanceSayTimesHello(int cnt)
        {
            return "I'll only say one hello, what ever you set the cnt";
        }

        public string ReplaceInstanceWithSetProperty(string propertyValue)
        {
            OwnProperty = propertyValue + " In replacer";
            return OwnProperty;
        }

        public string ReplaceInstanceWithSetPropertyInOriginContext(string propertyValue)
        {
            //BeInjectedClass context = (BeInjectedClass)this;
            dynamic tmpConvert = this;
            BeInjectedClass context = tmpConvert;
            context.CurrentHelloStr = propertyValue + " In replacer";
            return context.CurrentHelloStr;
        }

        public string GetMessage()
        {
            return "I won't tell you anything";
        }
        private void IWannaTouchYouAnyway(string injectMessage)
        {
            dynamic tmpConvert = this;
            BeInjectedClass context = tmpConvert;
            var field = context.GetType()
                .GetField("_privateMessage", BindingFlags.NonPublic | BindingFlags.Instance);
            field.SetValue(context,string.Format("Touched message:{0}",injectMessage));
        }

        public string ShowInjectMessage1(string message)
        {
            return string.Format("Intercept the class 1 message:{0}", message);
        }

        public string ShowInjectMessage2(string message)
        {
            return string.Format("Intercept the class 2 message:{0}", message);
        }

        public string InterceptWCFMessage(string message)
        {
            return string.Format("message has been intercepted:{0}", message);

        }

        public string GenericToString<T>(T value)
        {
            return string.Format("Intercept generic message:{0}",value.ToString());
        }

        public string InterceptGenericToString(string value)
        {
            return string.Format("I can do other things,Intercept generic message:{0}", value);
        }

        public string InterceptGenericToObject(object value)
        {
            return string.Format("this is intercept the object,Intercept generic message:{0}", value);
        }
        public string InterceptGenericToDouble(double value)
        {
            return string.Format("Got double value:{0}", value);
        }

        public static void InterceptWriteLineDouble(double value)
        {
            Console.WriteLine("I got you double:{0}",value);
        }

        public string CallOriginRecursive()
        {
            
            dynamic tmpConvert = this;
            BeInjectedClass context = tmpConvert;
            var result = context.WillBeInjectedRecursive();
            result = string.Format("Has been intercept the recursive call:{0}", result); 
            return result;
        }

        public string InterceptVirtualCall(string message)
        {
            return string.Format("Intercept message:{0}", message);
        }

        public string InterceptBaseVirtualCall(string message)
        {
            return string.Format("Intercept base message:{0}", message);
        }
    }
}