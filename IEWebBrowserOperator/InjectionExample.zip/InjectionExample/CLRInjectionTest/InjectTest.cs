﻿using System;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using BeInjectedLib;
using BeInjectedLib.TestWCFService;
using CLRInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CLRInjectionTest
{
    [TestClass]
    public class InjectTest
    {
        public string GetMessageFromInterface(IBeInjected injected, string message)
        {
            return injected.ShowMySelfWithMessage(message);
        }
        public string GetMessageFromClass(BeInjectedClass injected, string message)
        {
            return injected.VirtualCall(message);
        }
        //Interesting, the interceptor class call the inject method will not cause dead loop, it still call the origin method
        [TestMethod]
        [Ignore]
        public void RecursiveInjectTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.WillBeInjectedRecursive();
            Console.WriteLine(result);
            Assert.IsTrue(result == "Has been intercept the recursive call:Inject recursive");
        }

        //Interesting, the outer call the recusive inject method will still be intercept
        [TestMethod]
        [Ignore]
        public void RecursiveInjectTest2()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.CallTheInjectedRecursizeMethod();
            Console.WriteLine(result);
            Assert.IsTrue(result == "Has been intercept the recursive call:Inject recursive");
        }
        //Generic method can't work with this library
        [TestMethod]
        [Ignore]
        public void GenericMethodTest()
        {
            SetupGenericMethodInject();
            BeInjectedClass org = new BeInjectedClass();
            var result = org.GenericToString(100);
            Console.WriteLine(result);
            
            org = new BeInjectedClass();
            var resultDouble = org.GenericToString(100d);
            Console.WriteLine(resultDouble);


            var resultStr = org.GenericToString("abc");
            Console.WriteLine(resultStr);

            var resultObject = org.GenericToString(new object());
            Console.WriteLine(resultObject);

            Assert.IsTrue(result == "Intercept generic message:100");
            Assert.IsTrue(resultDouble == "Got double value:100");
            Assert.IsTrue(resultStr == "I can do other things,Intercept generic message:abc");
            Assert.IsTrue(resultObject == "this is intercept the object,Intercept generic message:System.Object");
        }
        [TestMethod]
        public void InstanceTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.InstanceSayTimesHello(3);

            Console.WriteLine(result);
            Assert.IsTrue(result == "I'll only say one hello, what ever you set the cnt");
            Assert.IsTrue(string.IsNullOrEmpty(org.CurrentHelloStr));
            var outerCallResult = org.ShowMeSomething();
            Console.WriteLine("outerCallResult:{0}",outerCallResult);
            Assert.IsTrue(outerCallResult == "I'll only say one hello, what ever you set the cnt");
        }

        [TestMethod]
        public void InstanceWithSetPropertyInOriginTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.SetPropertyInOrigin("Become Now");

            Console.WriteLine("result:{0}", result);
            Console.WriteLine("org.CurrentHelloStr:{0}", org.CurrentHelloStr);
            Console.WriteLine("org.CurrentStr:{0}", org.CurrentStr);
            Assert.IsTrue(result == "Become Now In replacer");
            Assert.IsTrue(string.IsNullOrEmpty(org.CurrentStr));
            Assert.IsTrue(org.CurrentHelloStr == result);
        }

        //Interesting situation, 
        //the replacer class don't have the property in injected class, but code still run without error
        [TestMethod]
        [Ignore]
        public void InstanceWithSetPropertyTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.SetProperty("Become Now");

            Console.WriteLine("result:{0}", result);
            Console.WriteLine("org.CurrentHelloStr:{0}", org.CurrentHelloStr);
            Console.WriteLine("org.CurrentStr:{0}", org.CurrentStr);
            Assert.IsTrue(result == "Become Now In replacer");
            Assert.IsTrue(string.IsNullOrEmpty(org.CurrentHelloStr));
            Assert.IsTrue(org.CurrentStr == result);
        }

        [TestMethod]
        public void InterfaceInjectTest()
        {
            BeInjectedDerivedClass1 class1 = new BeInjectedDerivedClass1();
            BeInjectedDerivedClass2 class2 = new BeInjectedDerivedClass2();
            var result1 = GetMessageFromInterface(class1, "Hello");
            var result2 = GetMessageFromInterface(class2, "Hello");
            Console.WriteLine(result1);
            Console.WriteLine(result2);
            Assert.IsTrue(result1 == "Intercept the class 1 message:Hello");
            Assert.IsTrue(result2 == "Intercept the class 2 message:Hello");
        }

        [TestMethod]
        public void PrivateMethodInjectTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            org.InvokeSetPrivateMessage("Origin message");
            var result = org.Message;
            Console.WriteLine(result);
            Assert.IsTrue(result != "Origin message");
            Assert.IsTrue(result == "Touched message:Origin message");
        }

        [TestMethod]
        public void PropertyInjectTest()
        {
            BeInjectedClass org = new BeInjectedClass();
            var result = org.ConstMessage;
            Console.WriteLine(result);
            Assert.IsTrue(result != "Hey, let me tell you something");
            Assert.IsTrue(result == "I won't tell you anything");
        }

        [TestMethod]
        public void StaticTest()
        {
            string result = BeInjectedClass.StaticGetStringWithOrigin("Hello");
            Console.WriteLine(result);
            Assert.IsTrue(result == "I'm mute guy, can't tell you anything");
        }

        [TestMethod]
        public void DeriveTest()
        {
            BeInjectedClass class1 = new BeInjectedClass();
            DeriveFromInjectClass class2 = new DeriveFromInjectClass();
            var result1 = GetMessageFromClass(class1, "Hello");
            var result2 = GetMessageFromClass(class2, "Hello");
            Console.WriteLine(result1);
            Console.WriteLine(result2);
            Assert.IsTrue(result1 == "Intercept base message:Hello");
            Assert.IsTrue(result2 == "Intercept message:Hello");
        }
        [TestMethod]
        [Ignore]
        public void GACTest()
        {
            SetupGACInject();

            double value = 100;
            Console.WriteLine(value);

        }
        [TestInitialize]
        public void TestSetup()
        {

            SetupStaticInject();
            SetupInstanceInject();
            SetupInstanceInjectWithClassPropertySet();
            SetupInstanceInjectWithClassPropertySetInOrigin();
            SetupPrivateMethod();
            SetupWCFInject();
            SetupInterfaceInject();
            SetupPropertyInject();
            SetupRecursiveInject();
            SetupDeriveInject();

            
        }


        [TestMethod]
        public void WCFServiceTest()
        {
            TestServiceClient client = new TestServiceClient(
                new BasicHttpBinding(), new EndpointAddress("http://http://localhost:1326/TestService.svc"));
            var result = client.GetData("Test");
            Console.WriteLine(result);
            Assert.IsTrue(result == "message has been intercepted:Test");
            Assert.IsTrue(result != "Test");
        }

        #region Method replace setup

        private void SetupGACInject()
        {
            var destMethods = typeof(Console)
                .GetMethods(BindingFlags.Static | BindingFlags.Public).Where(info => info.Name == "WriteLine").ToArray();
            var destMethod = destMethods.First(info => info.ToString() == "Void WriteLine(Double)");
            
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "InterceptWriteLineDouble",
                BindingFlags.Static | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupGenericMethodInject()
        {

            var destMethod = typeof(BeInjectedClass)
                  .GetMethod("GenericToString", BindingFlags.Instance | BindingFlags.Public);

            //Generate object IL code and intercept
            var closeDestMethodObject = destMethod.MakeGenericMethod(typeof(object));
            var closeSrcMethodObject = typeof(MethodInterceptor).GetMethod(
                                                                "InterceptGenericToObject",
                BindingFlags.Instance | BindingFlags.Public);

            MethodUtil.ReplaceMethod(closeSrcMethodObject, closeDestMethodObject);

            //Generate string IL code and intercept
            var closeDestMethodString = destMethod.MakeGenericMethod(typeof(string));
            var closeSrcMethodString = typeof(MethodInterceptor).GetMethod(
                                                                "InterceptGenericToString",
                BindingFlags.Instance | BindingFlags.Public);

            MethodUtil.ReplaceMethod(closeSrcMethodString, closeDestMethodString);


            //Generate int IL code and intercept

            var closeDestMethod = destMethod.MakeGenericMethod(typeof(int));
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "GenericToString",
                BindingFlags.Instance | BindingFlags.Public);
            var closeSrcMethod = srcMethod.MakeGenericMethod(typeof(int));
            MethodUtil.ReplaceMethod(closeSrcMethod, closeDestMethod);



            //Generate double IL code and intercept
            var closeDestMethodDouble = destMethod.MakeGenericMethod(typeof(double));
            var closeSrcMethodDouble = typeof(MethodInterceptor).GetMethod(
                                                                "InterceptGenericToDouble",
                BindingFlags.Instance | BindingFlags.Public);

            MethodUtil.ReplaceMethod(closeSrcMethodDouble, closeDestMethodDouble);
        }

        private void SetupInstanceInject()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("InstanceSayTimesHello", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "ReplaceInstanceSayTimesHello",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupInstanceInjectWithClassPropertySet()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("SetProperty", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "ReplaceInstanceWithSetProperty",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupInstanceInjectWithClassPropertySetInOrigin()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("SetPropertyInOrigin", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "ReplaceInstanceWithSetPropertyInOriginContext",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupInterfaceInject()
        {
            var destMethod1 = typeof(BeInjectedDerivedClass1)
                .GetMethod("ShowMySelfWithMessage", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod1 = typeof(MethodInterceptor).GetMethod(
                                                                 "ShowInjectMessage1",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod1, destMethod1);

            var destMethod2 = typeof(BeInjectedDerivedClass2)
                .GetMethod("ShowMySelfWithMessage", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod2 = typeof(MethodInterceptor).GetMethod(
                                                                 "ShowInjectMessage2",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod2, destMethod2);
        }


        private void SetupPrivateMethod()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("DontTouchMe", BindingFlags.Instance | BindingFlags.NonPublic);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "IWannaTouchYouAnyway",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupPropertyInject()
        {
            var property = typeof(BeInjectedClass)
                .GetProperty(
                             "ConstMessage", BindingFlags.Instance | BindingFlags.GetProperty | BindingFlags.Public);

            var destMethod = property.GetMethod;
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "GetMessage",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupRecursiveInject()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("WillBeInjectedRecursive", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "CallOriginRecursive",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupStaticInject()
        {
            var destMethod = typeof(BeInjectedClass)
                .GetMethod("StaticGetStringWithOrigin", BindingFlags.Static | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "ReplaceStaticGetStringWithOrigin",
                BindingFlags.Static | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupWCFInject()
        {
            var destMethod = typeof(TestServiceClient)
                .GetMethod("GetData", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod = typeof(MethodInterceptor).GetMethod(
                                                                "InterceptWCFMessage",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod, destMethod);
        }

        private void SetupDeriveInject()
        {
            var destMethod1 = typeof(BeInjectedClass)
                .GetMethod("VirtualCall", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod1 = typeof(MethodInterceptor).GetMethod(
                                                                 "InterceptBaseVirtualCall",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod1, destMethod1);

            var destMethod2 = typeof(DeriveFromInjectClass)
                .GetMethod("VirtualCall", BindingFlags.Instance | BindingFlags.Public);
            var srcMethod2 = typeof(MethodInterceptor).GetMethod(
                                                                 "InterceptVirtualCall",
                BindingFlags.Instance | BindingFlags.Public);
            MethodUtil.ReplaceMethod(srcMethod2, destMethod2);
        }
        #endregion
    }
}