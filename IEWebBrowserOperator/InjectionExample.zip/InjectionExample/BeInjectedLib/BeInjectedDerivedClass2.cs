﻿using System;

namespace BeInjectedLib
{
    public class BeInjectedDerivedClass2 : IBeInjected
    {
        public string ShowMySelfWithMessage(string message)
        {
            return string.Format("This message is from class2:{0}", message);
        }
    }
}