﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;

namespace BeInjectedLib
{
    public class BeInjectedClass
    {
        

        public int CurrentCnt { get; set; }
        public string CurrentStr { get; set; }
        public string CurrentHelloStr { get; set; }
        public static string StaticGetStringWithOrigin(string org)
        {
            return org;
        }

        public string Message
        {
            get
            {
                return _privateMessage;
            }
        }

        public string ConstMessage
        {
            get
            {
                return "Hey, let me tell you something";
            }
        }
        public void InvokeSetPrivateMessage(string message)
        {
            DontTouchMe(message);
        }
        private string _privateMessage;
        private void DontTouchMe(string interalMessage)
        {
            _privateMessage = interalMessage;
            
        }
        public string InstanceSayTimesHello(int cnt)
        {
            const string helloStr = "Hello";
            string result = "";
            for (int i = 0; i < cnt; i++)
            {
                result += helloStr;
            }
            CurrentHelloStr = result;
            return CurrentHelloStr;
        }

        public string SetProperty(string propertyValue)
        {
            CurrentHelloStr = propertyValue;
            return CurrentHelloStr;
        }
        public string SetPropertyInOrigin(string propertyValue)
        {
            CurrentHelloStr = propertyValue;
            return CurrentHelloStr;
        }
        public string GenericToString<T>(T value)
        {
            return value.ToString();
        }

        public string ShowMeSomething()
        {
            return InstanceSayTimesHello(5);
        }

        public string WillBeInjectedRecursive()
        {
            return "Inject recursive";
        }

        public string CallTheInjectedRecursizeMethod()
        {
            return WillBeInjectedRecursive();
        }

        public virtual string VirtualCall(string message)
        {
            return message;
        }
    }
}