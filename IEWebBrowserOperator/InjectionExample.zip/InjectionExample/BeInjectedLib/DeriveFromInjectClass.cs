﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeInjectedLib
{
    public class DeriveFromInjectClass:BeInjectedClass 
    {
        public override string VirtualCall(string message)
        {
            return string.Format("Derived message:{0}", message);
        }
    }
}
