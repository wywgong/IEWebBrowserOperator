﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeInjectedLib
{
    public interface IBeInjected
    {
        string ShowMySelfWithMessage(string message);
    }
}
