﻿using System;

namespace BeInjectedLib
{
    public class BeInjectedDerivedClass1 : IBeInjected
    {
        public string ShowMySelfWithMessage(string message)
        {
            return string.Format("This message is from class1:{0}", message);
        }
    }
}